<div class="element">
				<div class="text-center">
					<div class="section-title mb-5">Loaders</div>
				</div>
				<div class="row">
					<div class="col-lg-3 col-md-6 mb-5 mb-md-0">
						<div class="circle-progress">
							<div id="progress1"><canvas width="146" height="146"></canvas></div>
							<div class="progress-info">
								<h2>75%</h2>
								<p>Fashion</p>
							</div>		
						</div>
					</div>
					<div class="col-lg-3 col-md-6 mb-5 mb-md-0">
						<div class="circle-progress">
							<div id="progress2"><canvas width="146" height="146"></canvas></div>
							<div class="progress-info">
								<h2>83%</h2>
								<p>Portraits</p>
							</div>		
						</div>
					</div>
					<div class="col-lg-3 col-md-6 mb-5 mb-md-0">
						<div class="circle-progress">
							<div id="progress3"><canvas width="146" height="146"></canvas></div>
							<div class="progress-info">
								<h2>25%</h2>
								<p>Studio</p>
							</div>		
						</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="circle-progress">
							<div id="progress4"><canvas width="146" height="146"></canvas></div>
							<div class="progress-info">
								<h2>95%</h2>
								<p>Weddings</p>
							</div>		
						</div>
					</div>
				</div>
			</div>