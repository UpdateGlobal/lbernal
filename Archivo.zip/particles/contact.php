	<!-- page section start -->
	<section class="page-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 offset-lg-3 contect-tect">
					<h2>Hay que hablar</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet pharetra nisl. Vestibulum sollicitudin leo non purus vestibulum placerat. Curabitur ac erat sollicitudin, blandit quam vitae.</p>
				</div>
			</div>
			<form class="contact-form">
				<div class="row">
					<div class="col-md-6">
						<input type="text" placeholder="Nombre">
					</div>
					<div class="col-md-6">
						<input type="text" placeholder="E-mail">
					</div>
					<div class="col-md-6">
						<input type="text" placeholder="Me dejas tu Numero?">
					</div>
					<div class="col-md-6">
						<input type="text" placeholder="De que quieres hablar?">
					</div>
					<div class="col-md-12">
						<textarea placeholder="Cuentame"></textarea>
					</div>
				</div>
				<div class="text-center">
					<button class="site-btn">Avisame</button>
				</div>
			</form>
		</div>
	</section>
	<!-- page section end -->