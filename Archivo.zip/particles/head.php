	<title>Desarrollos web Frontend  Backend  Luis Desarrollador full stack venezolano residenciado en lima peru con nacionalidad española, blacksk81@gmail.com tlf: +51921966985</title>
	<meta charset="UTF-8">
	<meta name="description" content="Desarrollos web Frontend  Backend  Luis Desarrollador full stack venezolano residenciado en lima, blacksk81@gmail.com tlf: +51921966985" />
    <meta name="keywords" content="marketing, marketing digital, diseño web, diseño grafico, desarrollo de marca, creación de logotipos, paginas webs, branding" />
    <meta name="author" content="Desarrollo web Luis Bernal" />
    <link rel=”canonical” href=”https://lbernal.com.ve”/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	 <!-- twitter card starts from here, if you don't need remove this section -->
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@yourtwitterusername" />
    <meta name="twitter:creator" content="@yourtwitterusername" />
    <meta name="twitter:url" content="http://yourdomain.com" />
    <meta name="twitter:title" content="Your home page title, max 140 char" /> <!-- maximum 140 char -->
    <meta name="twitter:description" content="Your site description, maximum 140 char " /> <!-- maximum 140 char -->
    <meta name="twitter:image" content="assets/img/twittercardimg/twittercard-280-150.jpg" />  <!-- when you post this page url in twitter , this image will be shown -->
    <!-- twitter card ends from here -->

    <!-- facebook open graph starts from here, if you don't need then delete open graph related  -->
    <meta property="og:title" content="Desarrollo de pagìnas Webs" />
    <meta property="og:url" content="http://lbernal.com.ve/" />
    <meta property="og:locale" content="en_ES" />
    <meta property="og:site_name" content="freelance frontend Developer and webmaster" />
    <!--meta property="fb:admins" content="" /-->  <!-- use this if you have  -->
    <meta property="og:type" content="website" />
    <meta property="og:image" content="../img/luis-alberto-bernal.png" /> <!-- when you post this page url in facebook , this image will be shown -->
    <!-- facebook open graph ends from here -->

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:400,400i,600,600i,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/style.css"/>