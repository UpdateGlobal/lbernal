<!-- intro section start -->
	<section class="intro-section">
		<div class="container text-center">
			<div class="row">
				<div class="col-xl-10 offset-xl-1">
					<h2 class="section-title">Soy Freelance <span>Programador y Diseñador web UX/UI</span>, Con mas de 3 Años de Experiencia</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- intro section end -->