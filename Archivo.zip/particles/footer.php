	<!-- footer section start -->
	<footer class="footer-section text-center">
		<div class="container">
			<h2 class="section-title mb-5">Vamos a trabajar juntos</h2>
			<a href="contact.php" class="site-btn">Contactame</a>
			<div class="social-links" align="center">
				<a href="https://www.linkedin.com/in/luis-alberto-bernal-fuentes-6375143b/"><span class="fa fa-linkedin"></span></a>
				<a href="https://www.instagram.com/luisbernal2/"><span class="fa fa-instagram"></span></a>
				<a href="https://www.facebook.com/blacksk81"><span class="fa fa-facebook"></span></a>
			</div>
			<a href="https://instawidget.net/v/user/luisbernal2" id="link-950ed931fadf6634cb58401e5dbfab5671f98a34373ac474c5f66695d67c409f">@luisbernal2</a>
<script src="https://instawidget.net/js/instawidget.js?u=950ed931fadf6634cb58401e5dbfab5671f98a34373ac474c5f66695d67c409f&width=300px"></script>
		</div>
		</div>
	</footer>
	<!-- footer section end -->