<!-- header section start -->
	<header class="header-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-3">
					<div class="logo">
						<h2 class="site-logo">LuisB</h2>
					</div>
				</div>
				<div class="col-lg-8 col-md-9">
					<a href="" class="site-btn header-btn">Contactame</a>
					<nav class="main-menu">
						<ul>
							<li><a href="index.php">Inicio</a></li>
							<li><a href="about.php">YO!</a></li>
							<li><a href="blog.php">Blog</a></li>
							<li><a href="contact.php">Hablame</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
		<div class="nav-switch">
			<i class="fa fa-bars"></i>
		</div>
	</header>
	<!-- header section end -->